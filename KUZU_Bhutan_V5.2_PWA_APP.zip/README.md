# KUZU Bhutan — V3 Feature Build

This build adds the next major social features in one package:

- TikTok-style vertical feed
- Create account / sign in / sign out
- Likes, comments, follows and sharing
- **Messages / inbox** and 1-to-1 chat
- **Notifications** for likes, comments, follows and messages
- Creator profile and video grid
- Upload form with caption, hashtags, location and mentions
- Audience controls: **Public / Friends only / Private**
- Comment, download and remix/duet permissions stored with each video
- Search and Following feed
- Report and moderation data
- Persistent data through Netlify Blobs
- Mobile-first navigation

## Important video-upload note

The UI has been expanded for larger uploads, but Netlify Functions are not a suitable transport for large video files. This deployment path should keep uploads within the platform request limit. For true TikTok-style uploads (50–200+ MB), connect a direct-to-object-storage video service (for example, an S3-compatible bucket or dedicated video platform) and keep only metadata in Netlify Blobs.

Do **not** put private storage credentials in the frontend.

## Deploy

1. Upload the project to Netlify.
2. Add `KUZU_SESSION_SECRET` as a strong random environment variable.
3. Enable Netlify Blobs for the site.
4. Deploy.

## Next production storage step

For large videos, replace the `/api/videos` multipart upload with a signed/direct upload flow. The rest of the social data model can remain unchanged.


## V4.1 Live + Bhutan Gifts update
- Added KUZU Live section and live discovery UI.
- Added Game Live / Screen Share capture using the browser's display-capture permission, with optional microphone audio.
- Added a Live Studio preview so a creator can share a game screen while playing.
- Added live-room metadata endpoints and live gift events.
- Added Bhutan-inspired live gifts, including Blue Poppy, Takin, Thunder Dragon, Prayer Flags, Butter Lamp, Gho & Kira, Tsechu Mask, Yak, Taktsang, Snow Lion, Chorten, Guru Rinpoche, Ema Datshi, Chhang, Bamboo Basket, Khata, Himalayan Peaks, Royal Dragon, Tashi Delek, and .
- Momo was removed from the gift catalog.

### Important live-streaming note
This ZIP adds the creator-side screen/game capture and live-room/gift architecture. A real multi-viewer live broadcast still needs a WebRTC/SFU or managed live-video provider for internet-scale video distribution. Netlify Functions alone should not be used as the live video transport.

## V4.4 security hardening
- Server-side opaque sessions stored in Netlify Blobs instead of user IDs/signatures in the browser cookie.
- HttpOnly + Secure + SameSite=Strict session cookie; 7-day expiry and server-side logout revocation.
- PBKDF2-SHA-256 password hashing increased to 210,000 iterations with a unique random salt per password.
- Login and registration rate limiting to reduce brute-force and account-creation abuse.
- Security response headers including CSP, frame protection, MIME sniffing protection, referrer policy, and restricted browser permissions.
- Owner role is no longer automatically granted to the first account. Set `KUZU_OWNER_EMAIL` in Netlify environment variables for the intended owner account.
- Never store passwords, session tokens, or payment secrets in frontend code or localStorage.


## V4.5 account protection
- New accounts require email verification before sign-in.
- Verification links expire after 24 hours and are single-use.
- Forgot-password flow uses single-use, 30-minute reset links and revokes existing sessions after a password reset.
- Optional TOTP two-factor authentication works with authenticator apps such as Google Authenticator, Microsoft Authenticator and Authy.
- 2FA secrets are encrypted at rest with `KUZU_SESSION_SECRET`.
- 2FA challenges are single-use and expire after 5 minutes.

### Required Netlify environment variables for email features
Set these in **Site configuration → Environment variables**:
- `KUZU_SESSION_SECRET` — long random secret; keep private.
- `RESEND_API_KEY` — API key for the email provider.
- `KUZU_FROM_EMAIL` — verified sender address, for example `KUZU <no-reply@yourdomain.com>`.
- `KUZU_PUBLIC_URL` — your production URL, for example `https://your-site.netlify.app`.
- `KUZU_OWNER_EMAIL` — optional owner email.

The email provider is called server-side only. Never place the API key in React/frontend code.

### First deployment checklist for V4.5
1. Add the five environment variables above (four required for the security/email features, plus optional owner email).
2. Deploy.
3. Create a new test account and verify the email link.
4. Sign in and open **Profile → Account security → Enable 2FA**.
5. Add the secret to an authenticator app and confirm a 6-digit code.
6. Sign out and sign in again to verify the 2FA challenge.
7. Test **Forgot password?** and confirm the reset link works.

## V4.6 creator camera + music
- Added a camera-first posting flow with live filter preview.
- Added camera recording with selected visual filter rendered into the recorded WebM when browser support is available.
- Added a Bhutan Trending Music picker UI with slots for licensed/cleared tracks.
- Music selection is stored as creator-post metadata on the form; actual licensed audio files should be connected to the KUZU music library before production use.
- No Dzongkhag gifts were reintroduced.

## V5 account trust and anti-abuse
- Legitimate multiple accounts remain possible, but registration is rate-limited per device/network.
- Optional phone is recorded as an account contact; it is not treated as proof of identity until a real verification flow is connected.
- Security events and trust status are available through `/api/security/trust` and `/api/security/events`.
- Monetization eligibility endpoint `/api/monetization/eligibility` requires verified email + 2FA and no suspicious-activity flag.
- Device identifiers are only a friction/risk signal, not a permanent ban mechanism.

### V5.1 registration rate-limit update
- Increased the registration attempt limit to 10 per hour per IP and 10 per 24 hours per device/network signal.
- Uses new rate-limit keys so previously exhausted V5 test counters do not block the first V5.1 test.
- Abuse protection remains enabled; this is not a removal of rate limiting.
