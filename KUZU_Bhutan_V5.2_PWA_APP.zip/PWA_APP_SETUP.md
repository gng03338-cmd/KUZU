# KUZU PWA App Version

This package is the KUZU login-test version with Progressive Web App support added.

Deploy the contents of this ZIP to the same Netlify site. After deployment:
- Android/Chrome: open KUZU and choose "Install app" / "Add to Home screen".
- iPhone/iPad Safari: open KUZU, tap Share, then "Add to Home Screen".

The existing Netlify Functions/API files are preserved.
