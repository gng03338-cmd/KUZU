import { getStore } from '@netlify/blobs';
import type { Config, Context } from '@netlify/functions';

const store = () => getStore({ name: 'kuzu-main', consistency: 'strong' });
const json = (data: unknown, status = 200, headers: Record<string,string> = {}) => new Response(JSON.stringify(data), { status, headers: { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'x-content-type-options':'nosniff', ...headers } });
const id = () => crypto.randomUUID();
const now = () => new Date().toISOString();
const norm = (s:string) => s.trim().toLowerCase();
const enc = (s:string) => new TextEncoder().encode(s);
const b64u = (b:ArrayBuffer|Uint8Array) => { const a = b instanceof Uint8Array ? b : new Uint8Array(b); let s=''; for (const x of a) s+=String.fromCharCode(x); return btoa(s).replaceAll('+','-').replaceAll('/','_').replaceAll('=',''); };
const unb64u = (s:string) => { s=s.replaceAll('-','+').replaceAll('_','/'); while(s.length%4)s+='='; const bin=atob(s); const a=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i); return a; };
async function hashPassword(password:string, salt?:Uint8Array){ const s=salt||crypto.getRandomValues(new Uint8Array(16)); const key=await crypto.subtle.importKey('raw',enc(password),'PBKDF2',false,['deriveBits']); const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:s,iterations:210000,hash:'SHA-256'},key,256); return `${b64u(s)}.${b64u(bits)}`; }
async function verifyPassword(password:string, stored:string){ const [s,h]=stored.split('.'); if(!s||!h)return false; const computed=(await hashPassword(password,unb64u(s))).split('.')[1]; return computed===h; }
async function sha256(data:string){ return b64u(await crypto.subtle.digest('SHA-256',enc(data))); }
async function makeSession(userId:string){ const token=b64u(crypto.getRandomValues(new Uint8Array(32))); const exp=Date.now()+1000*60*60*24*7; await (await store()).setJSON(`session:${await sha256(token)}`,{userId,exp}); return token; }
async function session(req:Request){ const c=req.headers.get('cookie')||''; const m=c.match(/(?:^|;\s*)kuzu_session=([^;]+)/); if(!m)return null; const token=m[1]; const rec=await (await store()).get(`session:${await sha256(token)}`,{type:'json'}) as any; if(!rec||rec.exp<Date.now())return null; return rec.userId as string; }
const cookie=(v:string,max=60*60*24*7)=>`kuzu_session=${v}; Path=/; Max-Age=${max}; HttpOnly; SameSite=Strict; Secure; Priority=High`;
async function revokeSession(req:Request){ const c=req.headers.get('cookie')||''; const m=c.match(/(?:^|;\s*)kuzu_session=([^;]+)/); if(m)await (await store()).delete(`session:${await sha256(m[1])}`); }
const clientIp=(req:Request)=>req.headers.get('x-nf-client-connection-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'unknown';
const clientDevice=(req:Request)=>String(req.headers.get('x-kuzu-device')||'').trim().slice(0,120);
async function trustHash(value:string){return sha256(value||'unknown');}
async function recordSecurityEvent(userId:string,type:string,details:any={}){const s=await store();const eid=id();await s.setJSON(`security:${eid}`,{id:eid,userId,type,details,createdAt:now()});}
async function trustStatus(userId:string){const u=await getUser(userId);const events=(await list('security:')).filter((e:any)=>e.userId===userId).sort((a:any,b:any)=>b.createdAt.localeCompare(a.createdAt)).slice(0,20);return {accountAgeDays:u?.createdAt?Math.floor((Date.now()-Date.parse(u.createdAt))/86400000):0,emailVerified:!!u?.emailVerified,twoFactorEnabled:!!u?.twoFactorEnabled,securityEvents:events.length,monetizationEligible:!!u?.emailVerified&&!!u?.twoFactorEnabled&&!u?.suspiciousActivity};}
async function rateLimit(key:string, limit:number, windowMs:number){ const s=await store(); const k=`ratelimit:${key}`; const nowMs=Date.now(); const old=await s.get(k,{type:'json'}) as any; const rec=old&&old.reset>nowMs?old:{count:0,reset:nowMs+windowMs}; rec.count++; await s.setJSON(k,rec); return {ok:rec.count<=limit,retryAfter:Math.max(1,Math.ceil((rec.reset-nowMs)/1000))}; }
async function getUser(uid:string){return await (await store()).get(`user:${uid}`,{type:'json'}) as any;}
async function requireUser(req:Request){const uid=await session(req); if(!uid)return null; return await getUser(uid);}
async function list(prefix:string){const s=await store(); const out:any[]=[]; for await(const p of s.list({prefix})) { const v=await s.get(p.key,{type:'json'}); if(v)out.push(v); } return out;}
async function notify(userId:string,type:string,text:string){const s=await store(); await s.setJSON(`notification:${id()}`,{id:id(),userId,type,text,createdAt:now(),read:false});}

const env=(k:string)=>String(Netlify.env.get(k)||'').trim();
const hex = (a:ArrayBuffer|Uint8Array) => { const u=a instanceof Uint8Array?a:new Uint8Array(a); return Array.from(u,x=>x.toString(16).padStart(2,'0')).join(''); };
async function hmacSha1(keyBytes:Uint8Array,data:Uint8Array){ const k=await crypto.subtle.importKey('raw',keyBytes,{name:'HMAC',hash:'SHA-1'},false,['sign']); return new Uint8Array(await crypto.subtle.sign('HMAC',k,data)); }
const BASE32='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function base32Encode(bytes:Uint8Array){let out='',bits=0,val=0;for(const b of bytes){val=(val<<8)|b;bits+=8;while(bits>=5){bits-=5;out+=BASE32[(val>>bits)&31]}}if(bits)out+=BASE32[(val<<(5-bits))&31];return out;}
function base32Decode(s:string){s=s.replace(/=+$/,'').replace(/\s+/g,'').toUpperCase();let bits=0,val=0,out:number[]=[];for(const ch of s){const n=BASE32.indexOf(ch);if(n<0)throw new Error('Invalid 2FA secret');val=(val<<5)|n;bits+=5;if(bits>=8){bits-=8;out.push((val>>bits)&255)}}return new Uint8Array(out);}
async function totp(secret:string, at=Date.now()){const key=base32Decode(secret);const counter=Math.floor(at/1000/30);const msg=new Uint8Array(8);let x=counter;for(let i=7;i>=0;i--){msg[i]=x&255;x=Math.floor(x/256)}const mac=await hmacSha1(key,msg);const off=mac[mac.length-1]&15;const bin=((mac[off]&127)<<24)|(mac[off+1]<<16)|(mac[off+2]<<8)|mac[off+3];return String(bin%1000000).padStart(6,'0');}
async function verifyTotp(secret:string,code:string){const c=String(code||'').replace(/\D/g,'');for(const delta of [-1,0,1]){if((await totp(secret,Date.now()+delta*30000))===c)return true}return false;}
async function deriveAesKey(){const secret=env('KUZU_SESSION_SECRET');if(!secret)throw new Error('KUZU_SESSION_SECRET is not configured');return crypto.subtle.importKey('raw',await crypto.subtle.digest('SHA-256',enc(secret)),{name:'AES-GCM'},false,['encrypt','decrypt']);}
async function encryptSecret(value:string){const iv=crypto.getRandomValues(new Uint8Array(12));const k=await deriveAesKey();const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},k,enc(value)));return `${b64u(iv)}.${b64u(ct)}`;}
async function decryptSecret(value:string){const [ivS,ctS]=value.split('.');if(!ivS||!ctS)throw new Error('Invalid encrypted secret');const k=await deriveAesKey();const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64u(ivS)},k,unb64u(ctS));return new TextDecoder().decode(pt);}
async function sendEmail(to:string,subject:string,html:string){const key=env('RESEND_API_KEY'),from=env('KUZU_FROM_EMAIL'),site=env('KUZU_PUBLIC_URL');if(!key||!from||!site)return false;const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{'authorization':`Bearer ${key}`,'content-type':'application/json'},body:JSON.stringify({from,to,subject,html})});return r.ok;}
async function issueOneTime(prefix:string,payload:any,ttlMs:number){const token=b64u(crypto.getRandomValues(new Uint8Array(32)));await (await store()).setJSON(`${prefix}:${await sha256(token)}`,{...payload,exp:Date.now()+ttlMs});return token;}
async function consumeOneTime(prefix:string,token:string){const s=await store();const key=`${prefix}:${await sha256(token)}`;const rec=await s.get(key,{type:'json'}) as any;if(!rec||rec.exp<Date.now()){if(rec)await s.delete(key);return null}await s.delete(key);return rec;}
async function revokeAllSessions(uid:string){const s=await store();for await(const p of s.list({prefix:'session:'})){const rec=await s.get(p.key,{type:'json'}) as any;if(rec?.userId===uid)await s.delete(p.key)}}

export default async (req:Request, _context:Context) => {
  const url=new URL(req.url); const path=url.pathname.replace(/^\/api\/?/,''); const method=req.method.toUpperCase();
  if(path==='health') return json({ok:true,service:'KUZU',version:'2.0.0'});
  try{
    const s=await store();
    if(path==='auth/register' && method==='POST'){
      const rl=await rateLimit(`register-v2:${clientIp(req)}`,10,60*60*1000); if(!rl.ok)return json({error:'Too many account creation attempts. Please try again later.'},429,{'retry-after':String(rl.retryAfter)});
      const b=await req.json(); const email=norm(b.email||''); const password=String(b.password||''); const username=String(b.username||'').trim();
      const phone=String(b.phone||'').replace(/[^0-9+]/g,'').slice(0,20); const device=clientDevice(req); const deviceKey=await trustHash(device||clientIp(req));
      const deviceRl=await rateLimit(`device-register-v2:${deviceKey}`,10,24*60*60*1000); if(!deviceRl.ok)return json({error:'Too many new accounts from this device/network. Please try again later.'},429,{'retry-after':String(deviceRl.retryAfter)});
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||!password||password.length<10||!username) return json({error:'Enter a valid email, username and a password with at least 10 characters.'},400);
      if(username.length>30||/[<>]/.test(username)) return json({error:'Please choose a valid username.'},400);
      const existing=await s.get(`email:${email}`,{type:'json'}); if(existing) return json({error:'An account with that email already exists.'},409);
      if(env('KUZU_TEST_BYPASS_EMAIL_VERIFICATION')!=='true' && (!env('RESEND_API_KEY')||!env('KUZU_FROM_EMAIL')||!env('KUZU_PUBLIC_URL'))) return json({error:'Email verification is not configured yet. Add RESEND_API_KEY, KUZU_FROM_EMAIL and KUZU_PUBLIC_URL in Netlify Environment variables.'},503);
      const uid=id(); const role=env('KUZU_OWNER_EMAIL') && norm(env('KUZU_OWNER_EMAIL'))===email?'owner':'user'; const testBypass=env('KUZU_TEST_BYPASS_EMAIL_VERIFICATION')==='true'; const user={id:uid,username:username.slice(0,30),email,phone,avatar:'',bio:'',followers:0,following:0,role,createdAt:now(),emailVerified:testBypass,twoFactorEnabled:false,trustLevel:'new',suspiciousActivity:false};
      await s.setJSON(`user:${uid}`,{...user,passwordHash:await hashPassword(password)}); await s.setJSON(`email:${email}`,{userId:uid}); if(phone) await s.setJSON(`account-contact:phone:${await trustHash(phone)}:${uid}`,{userId:uid,type:'phone',createdAt:now()}); await s.setJSON(`account-contact:device:${deviceKey}:${uid}`,{userId:uid,type:'device',createdAt:now()}); await recordSecurityEvent(uid,'account_created',{deviceKey,ip:clientIp(req)});
      const token=await issueOneTime('verify',{userId:uid},24*60*60*1000); const link=`${env('KUZU_PUBLIC_URL').replace(/\/$/,'')}/?verify=${encodeURIComponent(token)}`;
      if(!testBypass){ await sendEmail(email,'Verify your KUZU account',`<p>Welcome to KUZU 🇧🇹</p><p>Verify your email address to activate your account.</p><p><a href="${link}">Verify my KUZU email</a></p><p>This link expires in 24 hours.</p>`); }
      return json({user,requiresVerification:true},201);
    }
    if(path==='auth/login' && method==='POST'){
      const b=await req.json(); const email=norm(b.email||''); const rl=await rateLimit(`login:${clientIp(req)}:${email}`,10,15*60*1000); if(!rl.ok)return json({error:'Too many sign-in attempts. Please wait before trying again.'},429,{'retry-after':String(rl.retryAfter)});
      const ref=await s.get(`email:${email}`,{type:'json'}); if(!ref)return json({error:'Invalid email or password.'},401);
      const u=await getUser(ref.userId); if(!u||!(await verifyPassword(String(b.password||''),u.passwordHash)))return json({error:'Invalid email or password.'},401);
      if(u.emailVerified===false && env('KUZU_TEST_BYPASS_EMAIL_VERIFICATION')!=='true')return json({error:'Please verify your email before signing in.'},403);
      if(u.twoFactorEnabled){const challenge=await issueOneTime('mfa_challenge',{userId:u.id},5*60*1000);return json({requires2FA:true,challenge});}
      const {passwordHash,...user}=u; return json({user},200,{'set-cookie':cookie(await makeSession(u.id))});
    }
    if(path==='auth/verify-email' && method==='POST'){
      const b=await req.json(); const rec=await consumeOneTime('verify',String(b.token||'')); if(!rec)return json({error:'Verification link is invalid or expired.'},400);
      const u=await getUser(rec.userId); if(!u)return json({error:'Account not found.'},404); u.emailVerified=true; await s.setJSON(`user:${u.id}`,u); const {passwordHash,...user}=u; return json({user},200,{'set-cookie':cookie(await makeSession(u.id))});
    }
    if(path==='auth/resend-verification' && method==='POST'){
      const b=await req.json(); const email=norm(b.email||''); const ref=await s.get(`email:${email}`,{type:'json'}); if(!ref)return json({ok:true}); const u=await getUser(ref.userId); if(!u||u.emailVerified!==false)return json({ok:true});
      const rl=await rateLimit(`verify:${clientIp(req)}:${email}`,3,60*60*1000); if(!rl.ok)return json({error:'Too many verification emails. Please try again later.'},429,{'retry-after':String(rl.retryAfter)});
      const token=await issueOneTime('verify',{userId:u.id},24*60*60*1000); const link=`${env('KUZU_PUBLIC_URL').replace(/\/$/,'')}/?verify=${encodeURIComponent(token)}`; await sendEmail(email,'Verify your KUZU account',`<p>Verify your KUZU email:</p><p><a href="${link}">Verify email</a></p><p>This link expires in 24 hours.</p>`); return json({ok:true});
    }
    if(path==='auth/forgot-password' && method==='POST'){
      const b=await req.json(); const email=norm(b.email||''); const ref=await s.get(`email:${email}`,{type:'json'}); const rl=await rateLimit(`reset:${clientIp(req)}:${email}`,3,60*60*1000); if(!rl.ok)return json({error:'Too many reset requests. Please try again later.'},429,{'retry-after':String(rl.retryAfter)});
      if(ref&&env('RESEND_API_KEY')&&env('KUZU_FROM_EMAIL')&&env('KUZU_PUBLIC_URL')){const u=await getUser(ref.userId);if(u){const token=await issueOneTime('reset',{userId:u.id},30*60*1000);const link=`${env('KUZU_PUBLIC_URL').replace(/\/$/,'')}/?reset=${encodeURIComponent(token)}`;await sendEmail(email,'Reset your KUZU password',`<p>We received a request to reset your KUZU password.</p><p><a href="${link}">Reset password</a></p><p>This link expires in 30 minutes. If you did not request this, ignore this email.</p>`);}}
      return json({ok:true,message:'If that email is registered, a password-reset link has been sent.'});
    }
    if(path==='auth/reset-password' && method==='POST'){
      const b=await req.json(); const password=String(b.password||''); if(password.length<10)return json({error:'Password must be at least 10 characters.'},400); const rec=await consumeOneTime('reset',String(b.token||'')); if(!rec)return json({error:'Reset link is invalid or expired.'},400); const u=await getUser(rec.userId); if(!u)return json({error:'Account not found.'},404); u.passwordHash=await hashPassword(password); u.emailVerified=true; await s.setJSON(`user:${u.id}`,u); await revokeAllSessions(u.id); return json({ok:true});
    }
    if(path==='auth/2fa/verify' && method==='POST'){
      const b=await req.json(); const rec=await consumeOneTime('mfa_challenge',String(b.challenge||'')); if(!rec)return json({error:'Two-factor challenge expired. Sign in again.'},401); const u=await getUser(rec.userId); if(!u||!u.twoFactorEnabled||!u.twoFactorSecret)return json({error:'Two-factor authentication is not enabled.'},401); const secret=await decryptSecret(u.twoFactorSecret); if(!(await verifyTotp(secret,String(b.code||''))))return json({error:'Invalid authenticator code.'},401); const {passwordHash,twoFactorSecret,...user}=u; return json({user},200,{'set-cookie':cookie(await makeSession(u.id))});
    }
    if(path==='auth/2fa/setup' && method==='POST'){
      const u=await requireUser(req); if(!u)return json({error:'Sign in required.'},401); if(u.twoFactorEnabled)return json({error:'Two-factor authentication is already enabled.'},400); const secret=base32Encode(crypto.getRandomValues(new Uint8Array(20))); const encrypted=await encryptSecret(secret); await s.setJSON(`mfa-setup:${u.id}`,{encrypted,exp:Date.now()+10*60*1000}); const issuer='KUZU'; const uri=`otpauth://totp/${encodeURIComponent(issuer+':'+u.email)}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`; return json({secret,otpauthUri:uri,expiresIn:600});
    }
    if(path==='auth/2fa/enable' && method==='POST'){
      const u=await requireUser(req); if(!u)return json({error:'Sign in required.'},401); const rec=await s.get(`mfa-setup:${u.id}`,{type:'json'}) as any; if(!rec||rec.exp<Date.now())return json({error:'2FA setup expired. Start setup again.'},400); const secret=await decryptSecret(rec.encrypted); if(!(await verifyTotp(secret,String((await req.json()).code||''))))return json({error:'Invalid authenticator code.'},400); u.twoFactorEnabled=true;u.twoFactorSecret=rec.encrypted;await s.setJSON(`user:${u.id}`,u);await s.delete(`mfa-setup:${u.id}`);return json({ok:true});
    }
    if(path==='auth/2fa/disable' && method==='POST'){
      const u=await requireUser(req); if(!u)return json({error:'Sign in required.'},401); const b=await req.json(); if(!(await verifyPassword(String(b.password||''),u.passwordHash)))return json({error:'Current password is incorrect.'},401); u.twoFactorEnabled=false;delete u.twoFactorSecret;await s.setJSON(`user:${u.id}`,u);return json({ok:true});
    }
    if(path==='auth/logout' && method==='POST'){ await revokeSession(req); return json({ok:true},200,{'set-cookie':cookie('',0)}); }
    if(path==='auth/me' && method==='GET'){const u=await requireUser(req); if(!u)return json({user:null}); const {passwordHash,...user}=u; return json({user});}

    if(path==='videos' && method==='GET'){
      const q=norm(url.searchParams.get('q')||''); const me=await requireUser(req); let items=await list('video:'); const followingIds=me?new Set((await list(`follow:${me.id}:`)).map(x=>x.to)):new Set(); const followerIds=me?new Set((await list('follow:')).filter(x=>x.to===me.id).map(x=>x.from)):new Set(); const friends=me?new Set([...followingIds].filter(x=>followerIds.has(x))):new Set(); if(url.searchParams.get('following')==='1'&&me)items=items.filter(v=>followingIds.has(v.userId)); items=items.filter(v=>v.visibility==='public'||(me&&v.userId===me.id)||(me&&v.visibility==='friends'&&friends.has(v.userId))); items=items.filter(v=>!q||`${v.username} ${v.caption} ${v.tags} ${v.location||''}`.toLowerCase().includes(q)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,100);
      return json({videos:items});
    }
    if(path==='videos' && method==='POST'){
      const u=await requireUser(req); if(!u)return json({error:'Sign in required.'},401); const fd=await req.formData(); const file=fd.get('video'); if(!(file instanceof File))return json({error:'Video file is required.'},400);
      if(file.size>5_000_000)return json({error:'Current free deployment upload limit is 5 MB. Connect direct video storage for larger uploads.'},413); if(!file.type.startsWith('video/'))return json({error:'Only video files are allowed.'},400);
      const vid=id(); const key=`media:${vid}`; await s.set(key,new Uint8Array(await file.arrayBuffer()),{metadata:{contentType:file.type}});
      const v={id:vid,userId:u.id,username:u.username,caption:String(fd.get('caption')||'').slice(0,500),tags:String(fd.get('tags')||'').slice(0,300),location:String(fd.get('location')||'').slice(0,100),mentions:String(fd.get('mentions')||'').slice(0,300),visibility:['public','friends','private'].includes(String(fd.get('visibility'))) ? String(fd.get('visibility')) : 'public',allowComments:fd.get('allowComments')==='on',allowDownload:fd.get('allowDownload')==='on',allowDuet:fd.get('allowDuet')==='on',likes:0,comments:0,createdAt:now(),media:`/api/media/${vid}`,avatar:u.avatar||''}; await s.setJSON(`video:${vid}`,v); return json({video:v},201);
    }
    const media=path.match(/^media\/([^/]+)$/); if(media&&method==='GET'){ const p=await s.get(`media:${media[1]}`,{type:'arrayBuffer'}); if(!p)return new Response('Not found',{status:404}); const meta=await s.getMetadata(`media:${media[1]}`); return new Response(p,{headers:{'content-type':meta?.metadata?.contentType||'video/mp4','cache-control':'public,max-age=31536000,immutable'}}); }

    if(path==='like' && method==='POST'){
      const u=await requireUser(req); if(!u)return json({error:'Sign in required.'},401); const b=await req.json(); const v=await s.get(`video:${b.videoId}`,{type:'json'}) as any; if(!v)return json({error:'Video not found.'},404); const key=`like:${u.id}:${b.videoId}`; const exists=await s.get(key,{type:'json'}); if(exists){await s.delete(key);v.likes=Math.max(0,v.likes-1);}else{await s.setJSON(key,{userId:u.id,videoId:b.videoId,createdAt:now()});v.likes++;if(v.userId!==u.id)await notify(v.userId,'like',`${u.username} liked your video.`);} await s.setJSON(`video:${b.videoId}`,v); return json({liked:!exists,likes:v.likes});
    }
    if(path==='follow' && method==='POST'){
      const u=await requireUser(req); if(!u)return json({error:'Sign in required.'},401); const b=await req.json(); if(b.userId===u.id)return json({error:'You cannot follow yourself.'},400); const target=await getUser(b.userId); if(!target)return json({error:'User not found.'},404); const key=`follow:${u.id}:${b.userId}`; const exists=await s.get(key,{type:'json'}); if(exists){await s.delete(key);u.following=Math.max(0,(u.following||0)-1);target.followers=Math.max(0,(target.followers||0)-1);}else{await s.setJSON(key,{from:u.id,to:b.userId,createdAt:now()});u.following=(u.following||0)+1;target.followers=(target.followers||0)+1;await notify(target.id,'follow',`${u.username} followed you.`);} await s.setJSON(`user:${u.id}`,{...u});await s.setJSON(`user:${target.id}`,{...target});return json({following:!exists});
    }
    const comments=path.match(/^comments\/([^/]+)$/); if(comments&&method==='GET') return json({comments:await list(`comment:${comments[1]}:`)});
    if(comments&&method==='POST'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const b=await req.json();const v=await s.get(`video:${comments[1]}`,{type:'json'}) as any;if(!v)return json({error:'Video not found.'},404);const c={id:id(),videoId:v.id,userId:u.id,username:u.username,text:String(b.text||'').slice(0,500),createdAt:now()};await s.setJSON(`comment:${v.id}:${c.id}`,c);v.comments++;await s.setJSON(`video:${v.id}`,v);if(v.userId!==u.id)await notify(v.userId,'comment',`${u.username} commented on your video.`);return json({comment:c},201);}
    if(path==='messages'&&method==='GET'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const all=await list('message:');const mine=all.filter(m=>m.from===u.id||m.to===u.id);const ids=[...new Set(mine.map(m=>m.from===u.id?m.to:m.from))];const people=[];for(const uid of ids){const other=await getUser(uid);if(!other)continue;const last=mine.filter(m=>m.from===uid||m.to===uid).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))[0];people.push({userId:uid,username:other.username,lastMessage:last?.text||''});}return json({messages:people});}
    const messagePath=path.match(/^messages\/([^/]+)$/); if(messagePath&&method==='GET'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const target=await getUser(messagePath[1]);if(!target)return json({error:'User not found.'},404);const all=await list('message:');const out=all.filter(m=>(m.from===u.id&&m.to===target.id)||(m.from===target.id&&m.to===u.id)).sort((a,b)=>a.createdAt.localeCompare(b.createdAt)).slice(-100).map(m=>({...m,mine:m.from===u.id}));return json({messages:out});}
    if(path==='messages'&&method==='POST'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const b=await req.json();const target=await getUser(String(b.to||''));const text=String(b.text||'').trim();if(!target||!text)return json({error:'Recipient and message are required.'},400);const m={id:id(),from:u.id,to:target.id,text:text.slice(0,1000),createdAt:now()};await s.setJSON(`message:${m.id}`,m);await notify(target.id,'message',`${u.username} sent you a message.`);return json({message:{...m,mine:true}},201);}
    if(path==='live'&&method==='GET'){const rooms=(await list('live:')).filter(r=>r.live).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,50);return json({rooms});}
    if(path==='live'&&method==='POST'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const b=await req.json();if(b.action==='end'&&b.roomId){const room=await s.get(`live:${b.roomId}`,{type:'json'}) as any;if(!room||room.userId!==u.id)return json({error:'Live room not found.'},404);room.live=false;room.endedAt=now();await s.setJSON(`live:${room.id}`,room);return json({room});}const room={id:id(),userId:u.id,username:u.username,title:String(b.title||`${u.username}'s KUZU Live`).slice(0,120),mode:['gaming','screen','camera'].includes(String(b.mode))?String(b.mode):'camera',viewers:1,live:true,createdAt:now()};await s.setJSON(`live:${room.id}`,room);return json({room},201);}
    const liveGift=path.match(/^live\/([^/]+)\/gift$/); if(liveGift&&method==='POST'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const room=await s.get(`live:${liveGift[1]}`,{type:'json'}) as any;if(!room||!room.live)return json({error:'Live room is not active.'},404);const b=await req.json();const gift={id:id(),roomId:room.id,userId:u.id,from:u.username,giftId:String(b.giftId||''),name:String(b.name||'Gift').slice(0,80),cost:Number(b.cost)||0,createdAt:now()};await s.setJSON(`livegift:${gift.id}`,gift);if(room.userId!==u.id)await notify(room.userId,'gift',`${u.username} sent ${gift.name} in your live.`);return json({gift},201);}

    if(path==='notifications'&&method==='GET'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);return json({notifications:(await list('notification:')).filter(n=>n.userId===u.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,50)});}
    if(path==='security/trust'&&method==='GET'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);return json(await trustStatus(u.id));}
    if(path==='security/events'&&method==='GET'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);return json({events:(await list('security:')).filter((e:any)=>e.userId===u.id).sort((a:any,b:any)=>b.createdAt.localeCompare(a.createdAt)).slice(0,50)});}
    if(path==='monetization/eligibility'&&method==='GET'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);return json(await trustStatus(u.id));}
    if(path==='profile'&&method==='GET'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const {passwordHash,...user}=u;return json({user,videos:(await list('video:')).filter(v=>v.userId===u.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))});}
    if(path==='block'&&method==='POST'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const b=await req.json();if(b.userId===u.id)return json({error:'Invalid user.'},400);const target=await getUser(b.userId);if(!target)return json({error:'User not found.'},404);const key=`block:${u.id}:${b.userId}`;const exists=await s.get(key,{type:'json'});if(exists){await s.delete(key)}else{await s.setJSON(key,{from:u.id,to:b.userId,createdAt:now()})}return json({blocked:!exists});}
    if(path==='admin/reports'&&method==='GET'){const u=await requireUser(req);if(!u||u.role!=='owner')return json({error:'Owner access required.'},403);return json({reports:(await list('report:')).sort((a,b)=>b.createdAt.localeCompare(a.createdAt))});}
    if(path==='report'&&method==='POST'){const u=await requireUser(req);if(!u)return json({error:'Sign in required.'},401);const b=await req.json();await s.setJSON(`report:${id()}`,{id:id(),userId:u.id,videoId:b.videoId||'',reason:String(b.reason||'Other').slice(0,200),createdAt:now(),status:'open'});return json({ok:true});}
    return json({error:'Not found'},404);
  }catch(e){console.error(e);return json({error:'Server error. Check Netlify function logs.'},500)}
};
export const config: Config = { path: '/api/*' };
